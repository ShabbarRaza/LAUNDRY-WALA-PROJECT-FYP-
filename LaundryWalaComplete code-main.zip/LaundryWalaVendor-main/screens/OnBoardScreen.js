import { Image, StyleSheet } from "react-native";
import React from "react";
import { LinearGradient } from "expo-linear-gradient";

import Onboarding from "react-native-onboarding-swiper";

class Boarding extends React.Component {
  render() {
    return (
      <LinearGradient colors={["#ffE3B3", "#00EDFF"]} style={{ flex: 1 }}>
        <Onboarding
          //bottomBarColor={'black'}
          onDone={() => this.props.navigation.navigate("Registration")}
          onSkip={() => this.props.navigation.navigate("Registration")}
          pages={[
            {
              backgroundColor: "transparent",
              image: (
                <Image
                  style={styles.onBoardLogo}
                  source={require("../assets/AE.png")}
                />
              ),
              title:
                "Fill The Vendors Registration Form ENTER ALL THE INFORMATION",
              titleStyles: styles.titledesign,
              subTitleStyles: { color: "#929292" },
              subtitle: " تمام معلومات درج کریں فارم پُر کریں",
            },
            {
              backgroundColor: "transparent",
              image: (
                <Image
                  style={styles.onBoardLogo}
                  source={require("../assets/download.png")}
                />
              ),
              titleStyles: styles.titledesign,
              subTitleStyles: { color: "#929292" },
              title: "After Registration Log in into your account",
              subtitle: '"رجسٹریشن کے بعد اپنے اکاؤنٹ میں لاگ ان کریں"',
            },
            {
              backgroundColor: "transparent",
              image: (
                <Image
                  style={styles.onBoardLogo}
                  source={require("../assets/w8ing.png")}
                />
              ),
              titleStyles: styles.titledesign,
              subTitleStyles: { color: "#929292" },
              title: "Now Wait for 72 Working hours For Our Reply",
              subtitle: "ہماری جواب کے لئے اب 72 کام کے اوقات کا انتظار کریں",
            },
          ]}
        />
      </LinearGradient>
    );
  }
}

const styles = StyleSheet.create({
  onBoardLogo: {
    width: 200,
    height: 200,
  },
  titledesign: {
    color: "black",
    fontWeight: "bold",
  },
});

export default Boarding;
